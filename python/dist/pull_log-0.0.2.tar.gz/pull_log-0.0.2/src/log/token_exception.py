

class TokenException(Exception):
    pass