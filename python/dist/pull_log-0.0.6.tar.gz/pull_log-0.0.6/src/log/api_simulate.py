import requests


def api_broken(robotId, errorCode=110123, msg='test'):
    params = (
        ('robotId', robotId),
        ('code', errorCode),
        ('msg', msg),
    )

    response = requests.get(
        'https://api-gate-dev-delivery.loomo.com/test/robot/simulation/error', params=params)

    print(response.content.decode('utf-8'))
